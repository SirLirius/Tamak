<?php
session_start();


$host = 'localhost'; 
$db = 'tamak2'; 
$user = 'root'; 
$pass = ''; 

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed :( " . $conn->connect_error);
}

$sql = "SELECT * FROM recipes LIMIT 8"; 
$result = $conn->query($sql);


if (!isset($_SESSION['favourites'])) {
    $_SESSION['favourites'] = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="homepage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>tamak.com</title>
</head>
<body>
    <header>
        <div class="container">
            <img src="Logo.png" alt="Logo">
            <nav>
                <ul class="nav-list">
                    <li><a href="homepage.php">Home</a></li>
                    <li><a href="favourite.php">Favourites</a></li>
                    <li><a href="login.php">Login</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <section class="hero">
        <div class="hero-section">
            <h2>Welcome to Tamak Recipe Collection!</h2>
            <p>Discover tasteful recipes to satisfy your receptors</p>
            <form action="results.php" method="get" class="search-box">
                <input type="text" name="query" placeholder="Search Recipes">
                <button type="submit">Search</button>
            </form>
        </div>
    </section>
    
    <section class="recipes">
        <h1>Featured Recipes</h1>
        <div class="recipe-section">
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <div class="recipe-card">
                        <img src="<?php echo htmlspecialchars($row['images']); ?>" alt="<?php echo htmlspecialchars($row['title']); ?>">
                        <h2><?php echo htmlspecialchars($row['title']); ?></h2>
                        <p><?php echo htmlspecialchars($row['description']); ?></p>
                        <a href="recipe.php?id=<?php echo $row['id']; ?>">View Recipe</a>
                        <button class="favourite-btn" data-id="<?php echo $row['id']; ?>">
                            <i class="fa fa-heart <?php echo in_array($row['id'], $_SESSION['favourites']) ? 'favourited' : ''; ?>"></i>
                        </button>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No recipes found.</p>
            <?php endif; ?>
        </div>
    </section>

    <footer>
        <div class="footerContainer">
            <div class="socialIcons">
                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-whatsapp"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
            </div>
            <div class="footerNav">
                <ul>
                    <li><a href="homepage.php">Home</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const favouriteButtons = document.querySelectorAll('.favourite-btn');
            
            favouriteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const recipeId = this.dataset.id;
                    const icon = this.querySelector('i');
                    const isFavourited = icon.classList.contains('favourited');

                    fetch('favourite.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ id: recipeId, action: isFavourited ? 'remove' : 'add' })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            icon.classList.toggle('favourited');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
                });
            });
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>
