<?php
session_start();

$host = 'localhost';
$db = 'tamak2';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed :( " . $conn->connect_error);
}
$user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $data = json_decode(file_get_contents('php://input'), true);
    $recipe_id = intval($data['id']);
    $action = $data['action'];
    $response = ['success' => false];
    
    if ($user_id > 0) {

        if ($action == 'remove') {
            $stmt = $conn->prepare("DELETE FROM favorites WHERE user_id = ? AND recipe_id = ?");
            $stmt->bind_param('ii', $user_id, $recipe_id);
            if ($stmt->execute()) {
                $response['success'] = true;
            }
            $stmt->close();
        } else if ($action == 'add') {
            $stmt = $conn->prepare("INSERT INTO favorites (user_id, recipe_id) VALUES (?, ?)");
            $stmt->bind_param('ii', $user_id, $recipe_id);
            if ($stmt->execute()) {
                $response['success'] = true;
            }
            $stmt->close();
        }
    }
    echo json_encode($response);
    exit;
}


$favourites = [];
if ($user_id > 0) {
    $sql = "SELECT r.id, r.title, r.description, r.images 
            FROM recipes r
            INNER JOIN favorites f ON r.id = f.recipe_id
            WHERE f.user_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $favourites[] = $row;
    }
    
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Favourites</title>
    <link rel="stylesheet" href="favourites.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <header>
        <div class="container">
            <img src="Logo.png">
            <nav>
                <ul class="nav-list">
                    <li><a href="homepage.php">Home</a></li>
                    <li><a href="favorite.php">Favourites</a></li>
                    <li><a href="login.php">Login</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="recipes">
        <div class="container">
            <div class="recipe-section">
                <?php if (!empty($favourites)): ?>
                    <?php foreach ($favourites as $recipe): ?>
                        <div class="recipe-card" data-id="<?php echo $recipe['id']; ?>">
                            <img src="<?php echo htmlspecialchars($recipe['images']); ?>" alt="<?php echo htmlspecialchars($recipe['title']); ?>">
                            <h2><?php echo htmlspecialchars($recipe['title']); ?></h2>
                            <p><?php echo htmlspecialchars($recipe['description']); ?></p>
                            <a href="recipe.php?id=<?php echo $recipe['id']; ?>">View Recipe</a>
                            <button class="favourite-btn" data-id="<?php echo $recipe['id']; ?>"><i class="fa fa-heart favourited"></i></button>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No favourites yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <footer>
        <div class="footerContainer">
            <div class="socialIcons">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-whatsapp"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
            </div>
            <div class="footerNav">
                <ul>
                    <li><a href="homepage.php">Home</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const favouriteButtons = document.querySelectorAll('.favourite-btn');

            favouriteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const recipeId = this.dataset.id;
                    const icon = this.querySelector('i');
                    const isFavourited = icon.classList.contains('favourited');
                    const action = isFavourited ? 'remove' : 'add';
                    const recipeCard = this.closest('.recipe-card');

                    fetch('favourite.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ id: recipeId, action: action })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            if (action === 'remove') {
                                recipeCard.remove();
                            } else {
                                icon.classList.toggle('favourited');
                            }
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
                });
            });
        });
    </script>
</body>
</html>
