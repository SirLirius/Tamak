<?php
session_start();


$host = 'localhost';
$db = 'tamak2';
$user = 'root';
$pass = '';


$conn = new mysqli($host, $user, $pass, $db);


if ($conn->connect_error) {
    die("Connection failed :( " . $conn->connect_error);
}
// Add to favourites
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['recipe_id'])) {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
        exit;
    }

    $user_id = $_SESSION['user_id'];
    $recipe_id = intval($_POST['recipe_id']);

    if ($recipe_id > 0) {
        $sql = "INSERT INTO favorites (user_id, recipe_id) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $user_id, $recipe_id);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to add to favourites']);
        }

        $stmt->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid recipe ID']);
    }

    $conn->close();
    exit;
}
// Search
$query = isset($_GET['query']) ? $_GET['query'] : '';

$query = $conn->real_escape_string($query);


$searchTerms = array_filter(array_map('trim', explode(' ', $query)));

if (count($searchTerms) > 0) {
    $sql = "SELECT * FROM recipes WHERE 1=1";
    foreach ($searchTerms as $term) {
        $term = $conn->real_escape_string($term);
        $sql .= " AND (ingredients LIKE '%$term%' OR title LIKE '%$term%')";
    }
} else {
    $sql = "SELECT * FROM recipes";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    <link rel="stylesheet" href="resultpage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <header>
        <div class="container">
            <img src="Logo.png" alt="Logo">
            <nav>
                <ul class="nav-list">
                    <li><a href="homepage.php">Home</a></li>
                    <li><a href="favourite.php">Favourites</a></li>
                    <li><a href="login.php">Login</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <form action="results.php" method="get" class="search-box">
        <input type="text" name="query" placeholder="Search Recipes" value="<?php echo htmlspecialchars($query); ?>">
        <button type="submit">Search</button>
    </form>

    <section class="recipes">
        <div class="recipe-section">
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <div class="recipe-card">
                        <img src="<?php echo htmlspecialchars($row['images']); ?>" alt="<?php echo htmlspecialchars($row['title']); ?>">
                        <h2><?php echo htmlspecialchars($row['title']); ?></h2>
                        <p><?php echo htmlspecialchars($row['description']); ?></p>
                        <a href="recipe.php?id=<?php echo $row['id']; ?>">View Recipe</a>
                        <button class="favourite-btn" data-id="<?php echo $row['id']; ?>">
                            <i class="fa fa-heart <?php echo in_array($row['id'], $_SESSION['favourites']) ? 'favourited' : ''; ?>"></i>
                        </button>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No recipes found for "<?php echo htmlspecialchars($query); ?>"</p>
            <?php endif; ?>
        </div>
    </section>

    <footer>
        <div class="footerContainer">
            <div class="socialIcons">
                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-whatsapp"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
            </div>
            <div class="footerNav">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </footer>
<!-- JavaScript for favouriting and un-favouriting recipes -->
    <script>
        $(document).ready(function() {
            $('.favourite-btn').on('click', function() {
                var recipeId = $(this).data('id');
                var $button = $(this);

                $.ajax({
                    url: 'results.php',
                    type: 'POST',
                    data: { recipe_id: recipeId },
                    success: function(response) {
                        var result = JSON.parse(response);
                        if (result.status == 'success') {
                            $button.find('i').toggleClass('favourited');
                        } else {
                            alert(result.message);
                        }
                    }
                });
            });
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>
