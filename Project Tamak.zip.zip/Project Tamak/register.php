<?php
session_start(); 

$servername = "localhost";
$username = "root";  
$password = "";
$database = "tamak2";

$conn = new mysqli($servername, $username, $password, $database); 

if ($conn->connect_error) {
    die("Connection failed :( " . $conn->connect_error);
}

// Check if email is already registered
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $name = $conn->real_escape_string($_POST['name']);

    $checkEmail = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $checkEmail->store_result();

    if ($checkEmail->num_rows > 0) {
        echo "Error: Email already registered";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $password);

        if ($stmt->execute()) {
            echo "Registration successful";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }

    $checkEmail->close();
}

$conn->close();
?>


 
<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Register</title>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <link rel='stylesheet' href='register.css'>
</head>

<body>

    <section>
        <div class="form-box">
            <div class="form-value">
                <form method="POST" action=""> 
                    <h2>Register</h2>
                    <div class="inputbox"> 
                        <ion-icon name="person-outline"></ion-icon> 
                        <input type="text" id="name" name="name" required>
                        <label for="name">Name</label>
                    </div>
                    <div class="inputbox"> 
                        <ion-icon name="mail-outline"></ion-icon> 
                        <input type="email" id="email" name="email" required> 
                        <label for="email">Email</label>
                    </div>
                    <div class="inputbox"> 
                        <ion-icon name="lock-closed-outline"></ion-icon> 
                        <input type="password" id="password" name="password" required> 
                        <label for="password">Password</label> 
                    </div>
                    <button type="submit">Register</button> 
                </form>
            </div>
        </div>
    </section> 
</body>

</html>
