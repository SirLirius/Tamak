<?php
session_start();

$host = 'localhost';
$db = 'tamak2';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed :( " . $conn->connect_error);
}

$recipe_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$sql = "SELECT * FROM recipes WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $recipe_id);
$stmt->execute();
$result = $stmt->get_result();
$recipe = $result->fetch_assoc();

if (!$recipe) {
    echo "Recipe not found.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comment'])) {
    $comment = $conn->real_escape_string($_POST['comment']);
    $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;

    if ($user_id > 0) {
        $sql = "INSERT INTO comments (recipe_id, user_id, comment) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('iis', $recipe_id, $user_id, $comment);
        $stmt->execute();
        $stmt->close();
    } else {
        echo "Please log in to comment.";
    }
}

$sql = "SELECT c.comment, c.created_at, u.name FROM comments c JOIN users u ON c.user_id = u.id WHERE c.recipe_id = ? ORDER BY c.created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $recipe_id);
$stmt->execute();
$comments_result = $stmt->get_result();
$comments = $comments_result->fetch_all(MYSQLI_ASSOC);

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="recipe.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title><?php echo htmlspecialchars($recipe['title']); ?></title>
</head>
<body>
    <header>
        <div class="container">
            <img src="Logo.png" alt="Logo">
            <nav>
                <ul class="nav-list">
                    <li><a href="homepage.php">Home</a></li>
                    <li><a href="#">Favourites</a></li>
                    <li><a href="login.php">Login</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <main class="container2">
        <img src="<?php echo htmlspecialchars($recipe['images']); ?>" alt="<?php echo htmlspecialchars($recipe['title']); ?>">
        <div class="recipe-info">
            <h1><?php echo htmlspecialchars($recipe['title']); ?></h1>
            <p class="description"><?php echo htmlspecialchars($recipe['description']); ?></p>
            <div class="ingredients">
                <h2>Ingredients</h2>
                <ul>
                    <?php
                    $ingredients = explode(',', $recipe['ingredients']);
                    foreach ($ingredients as $ingredient) {
                        echo '<li><span>' . htmlspecialchars($ingredient) . '</span></li>';
                    }
                    ?>
                </ul>
            </div>
            <hr>
            <div class="recipe-instruct">
                <h2>Instructions</h2>
                <div class="instructions">
                    <?php
                    $instructions = explode('.', $recipe['instructions']);
                    foreach ($instructions as $index => $instruction) {
                        if (!empty(trim($instruction))) {
                            echo '<div class="item">';
                            echo '<div class="num">' . ($index + 1) . '.</div>';
                            echo '<p><span>' . htmlspecialchars($instruction) . '</span></p>';
                            echo '</div>';
                        }
                    }
                    ?>
                </div>
            </div>
            <hr>
            <div class="cuisine">
                <h2>Cuisine</h2>
                <p><?php echo htmlspecialchars($recipe['cuisine']); ?></p>
            </div>
            <hr>
            <div class="comments">
                <h2>Comments</h2>
                <?php if (!empty($comments)): ?>
                    <?php foreach ($comments as $comment): ?>
                        <div class="comment">
                            <p><strong><?php echo htmlspecialchars($comment['name']); ?></strong> (<?php echo $comment['created_at']; ?>)</p>
                            <p><?php echo htmlspecialchars($comment['comment']); ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="no-comments">No comments yet.</p>
                <?php endif; ?>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <form method="post" action="" class="comment-form">
                        <textarea name="comment" rows="4" required></textarea>
                        <button type="submit">Add Comment</button>
                    </form>
                <?php else: ?>
                    <p class="login-prompt">Please <a href="login.php">Log in</a> to add a comment.</p>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <footer>
        <div class="footerContainer">
            <div class="socialIcons">
                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-whatsapp"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
            </div>
            <div class="footerNav">
                <ul>
                    <li><a href="homepage.php">Home</a></li>
                    <li><a href="#">Contact Us</a></li>
                </ul>
            </div>
        </div>
        <div class="footerBottom">
        </div>
    </footer>
</body>
</html>
